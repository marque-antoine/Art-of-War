# -*-coding:utf-8 -*-# -*-coding:utf-8 -*-
#MAIN


# Specification fonctionnelle du type Main

# Retourne une main vide pouvant accueillir de 0 à 6 cartes.
# x -> Main
def creerMain () : 
	return 0

# Met une carte dans le main du joueur
# Main*Carte -> x
def mettreCarteMain (main, carte) :
	return 0

# Renvoie n-ieme carte de la main et la supprime de celle-ci
# Main*int -> Carte
# pre : le numero de la carte demander est plus petit que que le nombre de carte du paquet
def getCarteMain (main, n) :
	return 0

# Renvoie le nombre de carte de la main
def nbCarteMain (main) :
	return 0

# Renvoie une chaine de cractere pour afficher la main 
#
# Doit être afficher sous cette forme
# 1 -> Garde | 2 -> Archer | 3 -> Archer 

#Ici le joueur à un garde et deux archers dans la main

def getStringMain (main) :
	return 0



