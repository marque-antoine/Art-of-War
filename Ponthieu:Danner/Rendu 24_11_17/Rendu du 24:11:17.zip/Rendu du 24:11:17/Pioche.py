# -*-coding:utf-8 -*-# -*-coding:utf-8 -*-
#Pioche

# Specification fonctionnelle du type Pioc


# Retourne une pioche remplie de 20 cartes : 9 soldats, 6 gardes et 5 archers
# Liste des fonctions appelees :
#		creerSoldat, creerGarde, creerArcher
# x -> Pioche
def creerPioche () : 
	return 0

# Renvoie une carte au hasard de la pioche. Retire la carte de la pioche.
# Il faut qu'il reste au moins une carte dans la pioche
# Pioche -> Carte
def piocherCarte (pioche):
	return 0
# Renvoie le nombre de carte restante dans la pioche
# Pioche -> int
def nbCartePioche (pioche): 
	return 0

def mettreCartePioche(pioche, carte) :
	return 0
