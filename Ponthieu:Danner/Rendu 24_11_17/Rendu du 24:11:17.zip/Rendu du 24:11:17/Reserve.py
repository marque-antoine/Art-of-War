# -*-coding:utf-8 -*-
# Reserve
# Specification fonctionnelle du type Reserve


# Cree une reserve vide qui peut contenir des cartes. Elle doit etre ordonnee en file d'attente. 
# La premier unite a rentrer dans la reserve sera la premiere a pouvoir en sortir
# x -> Reserve
def creerReserve ():
	return 0

# Place une carte dans la reserve
# pre : il faut faire attention que la reserve ne soit pas pleine 
# Reserve*Carte -> x
def placerCarteReserve (reserve, carte) :
	return 0


# Renvoie le combre de carte dans la reserve
# Reserve -> int
def getNbCarteReserve (reserve): 
	return 0


# Renvoie la acrte la plus a gauche de la reserve et la supprime de celle-ci
# Toute les cartes de la reserve doivent se decaler vers la gauche
# Reserve -> carte
def getCarteReserve (reserve) : 
	return 0

