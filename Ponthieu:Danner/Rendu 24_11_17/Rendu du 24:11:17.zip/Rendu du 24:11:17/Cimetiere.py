# -*-coding:utf-8 -*-
# Cimetiere

# Specification fonctionnelle du type Cimetiere


# Cree un cimetiere qui peut contenir des cartes
# x -> Cimetiere
def creerCimetiere ():
	return 0

# Permet de placer une carte dans le cimetière
# Carte*Cimetiere -> x
def placerCarteDansCimetiere(cimetiere, carte):
	return 0
